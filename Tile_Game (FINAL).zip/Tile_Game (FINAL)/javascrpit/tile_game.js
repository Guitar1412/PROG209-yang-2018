//Variables for buttons and stages
var menu = document.querySelector("#startMenu");
var stage = document.querySelector("#stage");
var output = document.querySelector("#output");
var musicBox = document.querySelector("#optionBox");
var guideBtn = document.getElementById("guideBtn");
var showBtn = document.querySelector("#startBtn");
var guide = document.getElementById('guide');
var closeGuideBtn = document.getElementById('closeGuideBtn');

//Start Game Button Event
showBtn.addEventListener("click",showStartMenu,false);
    
function showStartMenu() {
"use strict";

// Hide the intro screen, show the game screen
stage.style.display = "block";
menu.style.display = "none";
output.style.display = "block";
musicBox.style.display = "block";
}

//Guide button event
//Function that hides cover image and start game button.
var guideBttn = function() {
	"use strict";
	stage.style.display = "none";
	guide.style.display = "block";
	guideBtn.style.display = "none";
	closeGuideBtn.style.display = "block";
	};

	guideBtn.onclick = guideBttn;

//Guide button event
//Function that hides cover image and start game button.
var closeGuideBttn = function() {
	"use strict";
	stage.style.display = "block";
	guide.style.display = "none";
	guideBtn.style.display = "block";
	closeGuideBtn.style.display = "none";
	};

	closeGuideBtn.onclick = closeGuideBttn;

//Add a keyboard listener
window.addEventListener("keydown", keydownHandler, false);

//The game map
var map =
[
  [0, 0, 0, 0, 0, 1, 0, 7],
  [0, 0, 0, 0, 0, 6, 6, 6],
  [1, 0, 0, 7, 6, 6, 6, 3],
  [0, 0, 6, 0, 2, 6, 6, 0],
  [0, 0, 6, 1, 6, 6, 0, 0],
  [0, 6, 6, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 6, 6, 0, 2],
  [6, 0, 0, 0, 6, 6, 0, 0]
];

//The game objects map
var gameObjects =
[
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 5],
  [4, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0]
];

//Map code
var LAND = 0;
var MINI = 1;
var EGG = 2;
var CAMP = 3;
var HUNTER = 4;
var MONSTER = 5;
var OBSTACLE = 6;
var PALICO = 7;

//The size of each cell
var SIZE = 64;

//The number of rows and columns
var ROWS = map.length;
var COLUMNS = map[0].length;

//Find the hunter's and monster's start positions
var hunterRow;
var hunterColumn;
var monsterRow;
var monsterColumn;

for(var row = 0; row < ROWS; row++) 
{	
  for(var column = 0; column < COLUMNS; column++) 
  {
    if(gameObjects[row][column] === HUNTER)
    { 
      hunterRow = row;
      hunterColumn = column;
    }
    if(gameObjects[row][column] === MONSTER)
    { 
      monsterRow = row;
      monsterColumn = column;
    }
  }
}

//Arrow key codes
var UP = 38;
var DOWN = 40;
var RIGHT = 39;
var LEFT = 37;

//The game variables
var stamina = 40;
var meat = 10;
var eggs = 0;
var gameMessage = "Use the arrow keys to find your way back to camp.";
render();

function keydownHandler(event)
{ 
  switch(event.keyCode)
  {
      case UP:
          if(hunterRow > 0 && map[hunterRow - 1][hunterColumn] !== OBSTACLE)
          {
              //Clear the hunter's current cell
              gameObjects[hunterRow][hunterColumn] = 0;
              
              //Subract 1 from the hunter's row
              hunterRow--;
              
              //Apply the hunter's new updated position to the array
              gameObjects[hunterRow][hunterColumn] = HUNTER;
          }
          break;
          
      case DOWN:
          if(hunterRow < ROWS - 1 && map[hunterRow + 1][hunterColumn] !== OBSTACLE)
          {
              gameObjects[hunterRow][hunterColumn] = 0;
              hunterRow++;
              gameObjects[hunterRow][hunterColumn] = HUNTER;
          }
          break;
          
      case LEFT:
          if(hunterColumn > 0 && map[hunterRow][hunterColumn - 1] !== OBSTACLE)
          {
              gameObjects[hunterRow][hunterColumn] = 0;
              hunterColumn--;
              gameObjects[hunterRow][hunterColumn] = HUNTER;
          }
          break;  
          
      case RIGHT:
          if(hunterColumn < COLUMNS - 1 && map[hunterRow][hunterColumn + 1] !== OBSTACLE)
          {
              gameObjects[hunterRow][hunterColumn] = 0;
              hunterColumn++;
              gameObjects[hunterRow][hunterColumn] = HUNTER;
          }
          break; 
  }
	
  //find out what kind of cell the hunter is on
  switch(map[hunterRow][hunterColumn])
  {
    case LAND:
      gameMessage = "You are walking on open island.";
      break;
    
    case MINI:
      fight();
      break; 
    
    case PALICO:
      trade();
      break; 
          
    case CAMP:
      endGame();
      break;	
          
	case EGG:
      eggCollecting();
      break;
  }
    
  //Move the monster
  moveMonster();
  
  
  //Find out if the hunter is touching the monster
  if(gameObjects[hunterRow][hunterColumn] === MONSTER)
  {
    endGame();
  } 
	
  //Subtract some stamina each turn
  stamina--;
  
  //Find out if the hunter has run out of stamina or meat
  if(stamina <= 0 || meat <= 0)
  {
    endGame();
  }	
  
  //Render the game
  render();
}

let moveMonster = () =>
{
  //The 4 possible directions that the monster can move
  var UP = 1;
  var DOWN = 2;
  var LEFT = 3;
  var RIGHT = 4;
  
  //An array to store the valid direction that
  //the monster is allowed to move in
  var validDirections = [];
  
  //The final direction that the monster will move in
  var direction = undefined;
  
  //If the hunter has least 1 egg, the monster will start to chase the hunter
  if(eggs > 0)
  {
      if(monsterRow > hunterRow)
    {
        var thingAbove = map[monsterRow - 1][monsterColumn];
        
        if(thingAbove === LAND)
        {
            validDirections.push(UP);
        }
    }
    if(monsterRow < hunterRow)
    { 
        var thingBelow = map[monsterRow + 1][monsterColumn];
        
        if(thingBelow === LAND)
        {
            validDirections.push(DOWN);
        }
    }
    if(monsterColumn > hunterColumn)
    {
        var thingToTheLeft = map[monsterRow][monsterColumn - 1];
        if(thingToTheLeft === LAND)
        {
            validDirections.push(LEFT);
        }
    } 
    if(monsterColumn < hunterColumn)
    {
        var thingToTheRight = map[monsterRow][monsterColumn + 1];
        if(thingToTheRight === LAND)
        {
            validDirections.push(RIGHT);
        }
    } 
  }
  // Monster will move randomly when the hunter doesn't have egg
  else
  {
      if(monsterRow > 0)
    {
        var thingAbove2 = map[monsterRow - 1][monsterColumn];
        
        if(thingAbove2 === LAND)
        {
            validDirections.push(UP);
        }
    }
    if(monsterRow < ROWS - 1)
    { 
        var thingBelow2 = map[monsterRow + 1][monsterColumn];
        
        if(thingBelow2 === LAND)
        {
            validDirections.push(DOWN);
        }
    }
    if(monsterColumn > 0)
    {
        var thingToTheLeft2 = map[monsterRow][monsterColumn - 1];
        if(thingToTheLeft2 === LAND)
        {
            validDirections.push(LEFT);
        }
    } 
    if(monsterColumn < COLUMNS - 1)
    {
        var thingToTheRight2 = map[monsterRow][monsterColumn + 1];
        if(thingToTheRight2 === LAND)
        {
            validDirections.push(RIGHT);
        }
    } 
  }
	
  //The validDirections array now contains 0 to 4 directions that the 
  //contain LAND cells. Which of those directions will the monster
  //choose to move in?
  
  //If a valid direction was found, Randomly choose one of the 
  //possible directions and assign it to the direction variable
  if(validDirections.length !== 0)
  {
    var randomNumber = Math.floor(Math.random() * validDirections.length);
    direction = validDirections[randomNumber];
  }
  
  //Move the monster in the chosen direction
  switch(direction)
  {
    case UP:
      //Clear the monster's current cell
          gameObjects[monsterRow][monsterColumn] = 0;
      //Subtract 1 from the monster's row
          monsterRow--; 
      //Apply the monster's new updated position to the array
          gameObjects[monsterRow][monsterColumn] = MONSTER;
          break;
          
      case DOWN:
          gameObjects[monsterRow][monsterColumn] = 0;
          monsterRow++;
          gameObjects[monsterRow][monsterColumn] = MONSTER;
          break;
          
      case LEFT:
          gameObjects[monsterRow][monsterColumn] = 0;
          monsterColumn--;
          gameObjects[monsterRow][monsterColumn] = MONSTER;
          break;
          
      case RIGHT:
          gameObjects[monsterRow][monsterColumn] = 0;
          monsterColumn++;
          gameObjects[monsterRow][monsterColumn] = MONSTER;
  }
}
	
//Trading meat with PALICO to recover hunter's stamina
let trade = () =>
{
  //Figure out how much trade value the meat has currently
  //and how much it should cost to recover stamina
  var tradeValue = eggs + meat;
  var cost = Math.ceil(Math.random() * tradeValue);
  
  //Let the hunter recover some stamina if there's enough meat
  //to afford it
  if(meat > cost)
  {
    stamina += tradeValue;
    meat -= cost;
    
    gameMessage = "Palico has recover " + tradeValue + " stamina" + " for " + cost + " meat pieces.";
  }
  else
  {
    //Tell the player if they don't have enough meat
    gameMessage = "You don't have enough meat to buy stamina.";
  }
}

function fight()
{
  
  //The hunter's strength
  var hunterStrength = Math.ceil((stamina + meat) / 2);
  
  //A random number between 1 and the hunter's strength
  var miniStrength = Math.ceil(Math.random() * hunterStrength * 1.5);
  
  if(miniStrength > hunterStrength)
  {
    //Hunter loses meat when losing the fight, to lure the monster while running away.
    var huntermeat = Math.round(miniStrength / 5);
    meat -= huntermeat;
  
    //Update the game message
    gameMessage = "You fight and LOSE " + huntermeat + " meat pieces to lure mini monster away from you.";
	gameMessage += "<br>Hunter's strength: " + hunterStrength + " Mini monster's strength: " + miniStrength;
  }
  else
  {
    //You carve meat from mini monsters when winning the fight
    var monstermeat = Math.round(miniStrength / 2);
    meat += monstermeat;
    
    //Update the game message
    gameMessage = "You fight and WIN " + monstermeat + " meat pieces from the mini monsters.";
	gameMessage += "<br>Hunter's strength: " + hunterStrength + " Mini monster's strength: " + miniStrength;
  } 
}

//EggCollecting function event
let eggCollecting = () =>
{
	//Player collect 1 egg
    eggs += 1;
	map[hunterRow][hunterColumn] = LAND;
}

//End Game function event
function endGame()
{
  "use strict";
  //if the player return the camp with least 1 egg, the player wins the game.
  if(map[hunterRow][hunterColumn] === CAMP && eggs > 0)
  { 
    //Display the game message that the player has returned back to camp successfully.
      gameMessage = "You made it back to camp ALIVE! "; 
      document.getElementById('stage').style.display="none";
      document.getElementById('win').style.display="block";
	  guideBtn.style.display = "none";
	  closeGuideBtn.style.display = "none";
  }
  //Display the game message when the hunter has touched the monster.
  else if(gameObjects[hunterRow][hunterColumn] === MONSTER)
  {
      gameMessage = "You have been swallowed by the monster!";
      document.getElementById('stage').style.display="none";
      document.getElementById('fail').style.display="block";
	  guideBtn.style.display = "none";
	  closeGuideBtn.style.display = "none";
  }
  else
  {
    //Display the game message when the hunter's meat is less than 0 and lose the game.
    if(meat <= 0)
    {
        gameMessage = " You've run out of meat!"; 
        gameMessage += "<br> You have starved to death!";
        document.getElementById('stage').style.display="none";
        document.getElementById('fail').style.display="block";
		guideBtn.style.display = "none";
		closeGuideBtn.style.display = "none";
    }
	//Display the game message when the hunter's stamina is less than 0 and lose the game.
    else if (stamina <= 0)
    {
        gameMessage = " You've run out of stamina!"; 
        gameMessage += "<br> You are too tired to continue!";
        document.getElementById('stage').style.display="none";
        document.getElementById('fail').style.display="block";
		guideBtn.style.display = "none";
		closeGuideBtn.style.display = "none";
    }
	//Display the game message when the hunter has returned back to the camp without egg and lose the game.
    else
	{
        gameMessage = " Mission Failed! You must collect at least one egg back to the camp!";
        document.getElementById('stage').style.display="none";
        document.getElementById('fail').style.display="block";
		guideBtn.style.display = "none";
		closeGuideBtn.style.display = "none";
	}
     
  }
  
  //Remove the keyboard listener to end the game
  window.removeEventListener("keydown", keydownHandler, false);
}

function render()
{
  //Clear the stage of img tag cells
  //from the previous turn
  
  if(stage.hasChildNodes())
  {
    for(var i = 0; i < ROWS * COLUMNS; i++) 
    {	 
      stage.removeChild(stage.firstChild);
    }
  }
  
  //Render the game by looping through the map arrays
  for(var row = 0; row < ROWS; row++) 
  {	
    for(var column = 0; column < COLUMNS; column++) 
    { 
      //Create a img tag called cell
      var cell = document.createElement("img");
      //Set it's CSS class to "cell"
      cell.setAttribute("class", "cell");
      //Add the img tag to the <div id="stage"> tag
      stage.appendChild(cell);
      //Find the correct image for this map cell
      switch(map[row][column])
      {
        case LAND:
          cell.src = "images/land.png";
          break;
        case MINI:
          cell.src = "images/mini.png";
          break; 
        case EGG:
          cell.src = "images/eggs.png";
          break; 
        case CAMP:
          cell.src = "images/camp.png";
          break;   
		
		case OBSTACLE:
          cell.src = "images/land.png";
          break;
		case PALICO:
          cell.src = "images/palico2.png";
          break;
      } 
        //Add the hunter and monster from the gameObjects array
        switch(gameObjects[row][column])
        {
            case HUNTER:
                cell.src = "images/hunter.png";
                break;
                
            case MONSTER:
                cell.src = "images/monster3.png";
                break;
        } 
      //Position the cell 
      cell.style.top = row * SIZE + "px";
      cell.style.left = column * SIZE + "px";
    }
  }
      //Display the game message
      output.innerHTML = gameMessage;
	
      //Display the player's stamina, meat, and eggs
      output.innerHTML += "<br>Meat: " + meat + ", Stamina: " + stamina + ", Eggs: " + eggs;
}
