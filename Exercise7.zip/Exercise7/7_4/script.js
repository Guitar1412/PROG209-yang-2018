$(function() {
'use strict';
	$('#name2').on('click',function(){
		alert("ERROR!");
		console.log('ERROR!');
	});
	$('#email').prop('required',true);
	$('#phone').on('keyup',function(){
		console.log('Good Choice!');
	});
});