// JavaScript Document
//*****************************************************
//*****************************************************
//Made by: Kai-Hsiang Yang
//Description: This text adventure game is for learning purpose only.
//*****************************************************
//*****************************************************
	var coverSection = 1;
	var coverImage = document.getElementById("cover");
	var btnStart = document.getElementById("startBtn");
	var inputBox = document.getElementById("input");
	var imgBox = document.getElementById("imageBox");
	var outPut = document.getElementById("output");
	//var enterBtn = document.getElementById("button");
	var replayBtn = document.getElementById("replayBtn");
	var guideBtn = document.getElementById("helpBtn");
	var closeGuideBttn = document.getElementById("closeHelpBtn");
	var saveButton = document.getElementById("saveBtn");
	var loadButton = document.getElementById("loadBtn");
	var helpSection1 = document.getElementById("helpField");
	var helpSection2 = document.getElementById("helpField2");
	
//Function that hides cover image and start game button.
	var startBttn = function() {
		"use strict";
		coverImage.style.display = "none";
		btnStart.style.display = "none";
		inputBox.style.display = "block";
		imgBox.style.display = "block";
		outPut.style.display = "block";
		button.style.display = "block";
		guideBtn.style.display = "block";
		saveButton.style.display = "block";
		loadButton.style.display = "block";
		coverSection -= 1;
	};

	btnStart.onclick = startBttn;
	
//Function that shows guideline page.
	var guideBttn = function() {
		"use strict";
		guideBtn.style.display = "none";
		helpSection1.style.display = "none";
		helpSection2.style.display = "block";
		closeGuideBttn.style.display = "block";
	};
	
	guideBtn.onclick = guideBttn;
	
//Function that close guideline page.
	var closeGuideBtttn = function(){
		"use strict";
		guideBtn.style.display = "block";
		closeGuideBttn.style.display = "none";
		helpSection1.style.display = "block";
		helpSection2.style.display = "none";
	};
	
	closeGuideBttn.onclick = closeGuideBtttn;
	
//Function that shows replay button
	function replaybtn(){
		"use strict";
		replayBtn.style.display = "block";
		guideBtn.style.display = "none";
		saveButton.style.display = "none";
		loadButton.style.display = "none";
	}

//*****************************************************
//*****************************************************
	
//map locations array
var map = [];

//map 0 has lantern
map[0] = "Storage room with closets<br ><br > Guess this is where the house master stored all the tools.<br>";
//map 1 
map[1] = "Study room<br ><br > There is a fireplay, it can keep DD warm. DD can take a short break here.<br>";
//map 2 where the player starts
map[2] = "Room with a leaking ceiling<br ><br > Don't think there is anything in the room that can help DD to escape the place. Let's keep moving.<br>";
//map 3 locked, has mansion front door key
map[3] = "Office<br ><br > There are documents and books scattering over the floor.<br>";
//map 4 chance to encounter the monster
map[4] = "The hallway<br ><br >This is not a safe place to dwelling around.<br>";
//map 5 has key to unlock the office door, need to use the lantern to unlcok the area
map[5] = "The Gallery<br><br > Many long lost famous paintings can be found in this room!<br >";
//map 6 has trap
map[6] = "The laboratory<br ><br >Yike! Animal corpses are lying around all over the floor! Let's get out of here before DD gets sick.<br>";
//map 7 is front door of the mainsion, locked*
map[7] = "Front door<br ><br > There are some weird marks that have been carved on the door, DD wondered what those marks are...<br >";
map[8] = "A stair that leads to a dead end<br ><br > Let's turn back.<br>";
map[9] = "";
map[10] = "<br ><br >Outside of the haunted mansion<br ><br > Thanks to you, DD has safely escaped from the monster and moving on to her next adventure.";
map[11] = "";
	
//*****************************************************
//*****************************************************
	
//Set the player's start location
var mapLocation = 2;
	
//*****************************************************
//*****************************************************
	
//Allow the user to hit enter to submit the input, instead of click on the enter button
window.addEventListener("keydown", keydownHandler, false);

function keydownHandler( event ) {
	"use strict";
    if(mapLocation !== 10 && coverSection === 0){
		if (event.keyCode === 13) {
		playGame();
		input.value = "";
    }
	}
	
}
	
//*****************************************************
//*****************************************************

//Set the images array
var images = [];

images[0] = "0.jpg";
images[1] = "1.jpg";
images[2] = "2.jpg";
images[3] = "3.jpg";
images[4] = "4.jpg";
images[5] = "5.jpg";
images[6] = "6.jpg";
images[7] = "7.jpg";
images[8] = "8.jpg";
images[9] = "";
images[10] = "10.jpg";
images[11] = "";
	
//The img element
var image = document.querySelector("img");
	
//*****************************************************
//*****************************************************
	
//Set the blocked path messages
var blockedPathMessages = [];

blockedPathMessages[0] = "There is a wall. DD can't do anything to the wall.<br >";
blockedPathMessages[1] = "Please stay far away from the fireplace, let's not burn DD.<br >";
blockedPathMessages[2] = "There are only bookshelfs. The Exit is at the west side of the room.<br >";
blockedPathMessages[3] = "Desks and book piles are blocking the way.<br >";
blockedPathMessages[4] = "";
blockedPathMessages[5] = "Beautiful paintings on the wall.<br >";
blockedPathMessages[6] = "Shelfs filled with glass tubes, looks like there are some weird looking liquid in the tube as well, let's becareful not to knock them off the shelf.<br >";
blockedPathMessages[7] = "";
blockedPathMessages[8] = "Only piles of rocks on the ground, a dead end.<br >";
blockedPathMessages[9] = "";
blockedPathMessages[10] = "Let's hurry and drive the car to leave the place.<br >";
blockedPathMessages[11] = "";
	
//*****************************************************
//*****************************************************
	
//Set the hint messages
var hintMessages = [];

hintMessages[0] = "Lantern might be useful for later.<br >";
hintMessages[1] = "Nothing special in this room, let's go check out the other areas.";
hintMessages[2] = "There is an exit on the west side of the room.<br >";
hintMessages[3] = "DD should take the front door key with her.<br ><br >";
hintMessages[4] = "The office is at the west side and the gallery is at the east side.<br >";
hintMessages[5] = "If DD wants to unlock the office, she needs to take the office key with her.<br >";
hintMessages[6] = "Maybe DD can use the trap against the monster?<br ><br >";
hintMessages[7] = "Only if DD has front door key with her to unlock the front door...<br >";
hintMessages[8] = "Not much to see here, let's turn back.<br >";
hintMessages[9] = "";
hintMessages[10] = "";
hintMessages[11] = "";
	
//*****************************************************
//*****************************************************

//Create the items and set their locations
var items = ["lantern", "front door key", "office key", "trap"];
var itemLocations = [0, 3, 5, 6];
//An array to store what the player is carrying
var backpack = [];
	var itemsIKnow = ["lantern", "front door key", "office key", "trap"];
var item = "";

//*****************************************************
//*****************************************************	
//Set events variable
var doorLocked = 1;
var frontDoorLocked = 1;
var darkNess = 1;
var monster = 3;
var traps = 0;
var lanterns = 0;
//*****************************************************
//*****************************************************	

//Initialize the player's input
var playersInput = "";

//Initialize the gameMessage
var gameMessage = "";

//Create an array of actions the game understands
//and a variable to store the current action
var actionsIKnow = ["north", "east", "south", "west", "take lantern", "take office key", "take front door key", "take trap", "use lantern", "use office key", "use front door key", "use trap", "drop lantern", "drop office key", "drop front door key", "drop trap", "hide", "hint"];
var action = "";
	
//*****************************************************
//*****************************************************
	
function playGame()
{
  //Get the player's input and convert it to lowercase
  playersInput = input.value;
  playersInput = playersInput.toLowerCase();
  
  //Reset these variables from the previous turn
  gameMessage = "";
  action = "";
  
  //Figure out the player's action
  for(i = 0; i < actionsIKnow.length; i++)
  {
    if(playersInput.indexOf(actionsIKnow[i]) !== -1)
    {
      action = actionsIKnow[i];
      console.log("player's action: " + action);
      break;
    }
  }
  
//Figure out the item the player wants
  for(i = 0; i < itemsIKnow.length; i++)
  {
    if(playersInput.indexOf(itemsIKnow[i]) !== -1)
    {
      item = itemsIKnow[i];
      console.log("player's item: " + item);
    }
  }
  
//Choose the correct action
  switch(action)
  {
    case "north":
	  if(mapLocation === 0 || mapLocation === 3 || mapLocation === 5 || mapLocation === 6 || mapLocation === 8){
	  gameMessage = blockedPathMessages[mapLocation];
	  }
      else if(mapLocation > 3)
      {
        mapLocation -= 3;
      }
      else
      {
        gameMessage = blockedPathMessages[mapLocation];
      }
      break;
    
    case "east":
	  if(mapLocation === 4 && darkNess === 1){
		  gameMessage = "The room is pitch dark, it's not safe for DD to enter.<br >";
	  }
	  else if(mapLocation === 0 && monster === 3 && lanterns === 1){
		  gameMessage = "DD has heard foot steps coming from outside of the room, it's the monster! Quickly! Have DD hide in the closet! <br >";
	  }
	  
	  else if(mapLocation === 3 && monster === 2 && traps === 1){
		  gameMessage = "OH NO! The monster has found DD, use trap to stop the monster! <br >";
	  }
		  
	  else if(mapLocation % 3 !== 2)
      {
        mapLocation += 1;
      }
      
      else
      {
        gameMessage = blockedPathMessages[mapLocation];
      }
      break;
      
    case "south":
	  if(mapLocation === 0 || mapLocation === 2 || mapLocation === 3 || mapLocation === 5){
		gameMessage = blockedPathMessages[mapLocation];
	  }
	  else if(mapLocation === 7 && frontDoorLocked === 1){
		  gameMessage = "Front door is locked, let's find a key to unlock it.<br >";
	  }
	 
	  else if(mapLocation ===7){
		  mapLocation += 3;
		  button.style.display = "none";
		  inputBox.style.display = "none";
		  gameMessage = "<br >";
		  replaybtn();
	  }
		  
      else if(mapLocation < 6)
      {
        mapLocation += 3;
      }
	  
      else
      {
        gameMessage = blockedPathMessages[mapLocation];
      }
      break;
      
    case "west":
      if(mapLocation === 4 && doorLocked === 1){
		  gameMessage = "The office is locked... DD needs a key to unlock the door.<br >";
	  }
	  else if(mapLocation === 0){
		  gameMessage = blockedPathMessages[mapLocation];
	  }
	  else if(mapLocation % 3 !== 0)
      {
        mapLocation -= 1;
      }
      else
      {
        gameMessage = blockedPathMessages[mapLocation];
      }
      break;
	
      
    case "hint":
      //Display a hint if there is one for this location
      if(hintMessages[mapLocation] !== "")
      {
        gameMessage = hintMessages[mapLocation] + " ";
      }
      break;
      
    case "take lantern":
      takeItem();
	  break;
	
	case "take office key":
      takeItem();
	  break;
		  
	case "take front door key":
      takeItem();
	  break;
		  
	case "take trap":
      takeItem();
	  break;
		
	case "drop lantern":
	  dropItem();
	  break;
		  
	case "drop office key":
      dropItem();
	  break;
		  
	case "drop front door key":
      dropItem();
	  break;
		  
	case "drop trap":
      dropItem();
	  break;
		  
	case "use lantern":
	  useItem();
	  break;
		  
	case "use office key":
      useItem();
	  break;
		  
	case "use front door key":
      useItem();
	  break;
		  
	case "use trap":
      useItem();
	  break;
    		  
	default:
	  gameMessage = "DD can not understand your command.<br >";
  	  break;
		  
	case "hide":
	  if(mapLocation === 0){
		  gameMessage = "DD has went into the closet and hide. After the monster walked away, DD slowly walked out of the closet....<br >";
		  monster -= 1;
	  }	break;
}
  //Render the game
  render();
}
//*****************************************************
//*****************************************************
function takeItem()
{
  //Find the index number of the item in the items array
  var itemIndexNumber = items.indexOf(item);
  
  //Does the item exist in the game world
  //and is it at the player's current location?
  if(itemIndexNumber !== -1 && itemLocations[itemIndexNumber] === mapLocation){
	  gameMessage = "DD takes the " + item + ".<br >";
    
    //Add the item to the player's backpack 
    backpack.push(item);
   
    //Remove the item from the game world
    items.splice(itemIndexNumber, 1);
    itemLocations.splice(itemIndexNumber, 1);
          
    //Display in the console for testing
    console.log("World items: " + items);
    console.log("backpack items: " + backpack);
	  
	  if(item === "trap"){
		  traps += 1;
	  }
	  
	  else if(item === "lantern"){
		  lanterns += 1;
	  }
	
  }
  else
  {
    //Message if you try and take an item
    //that isn't in the current location
    gameMessage = "DD can't do that.";
  }
}

function dropItem()
{
  //Try to drop the item only if the backpack isn't empty
  if(backpack.length !== 0)
  {
    //Find the item's array index number in the backpack
    var backpackIndexNumber = backpack.indexOf(item);
	  
	if(backpackIndexNumber !== -1){
		//Tell the player that the item has been dropped
   	 gameMessage = "DD drop the " + item + ".";
     
     //Add the item from the backpack to the game world 
     items.push(backpack[backpackIndexNumber]);
     itemLocations.push(mapLocation); 
     
     //Remove the item from the player's backpack 
     backpack.splice(backpackIndexNumber, 1);
		
	if(item === "trap"){
		traps -= 1;
	}
		
	else if(item === "lantern"){
		lanterns -= 1;
	}
	}
	  //The item is in the backpack if backpackIndex number isn't -1
    else
    {
      //Message if the player tries to drop
      //something that's not in the backpack
      gameMessage = "DD can't do that.";
    }
  }
  else
  {
    //Message if the backpack is empty
    gameMessage = "DD is not carrying anything.";
  }
}

function useItem()
{
  //1. Find out if the item is in the backpack
  
  //Find the item's array index number in the backpack
  var backpackIndexNumber = backpack.indexOf(item);
       
  //If the index number is -1, then it isn't in the backpack.
  //Tell the player that he or she isn't carrying it.
  if(backpackIndexNumber === -1)
  {
    gameMessage = "DD is not carrying it.";
  }
  
  //If there are no items in the backpack, then
  //tell the player the backpack is empty
  if(backpack.length === 0)
  {
    gameMessage += " DD's backpack is empty";
  }
   
  //2. If the item is found in the backpack
  //figure out what to do with it
  if(backpackIndexNumber !== -1)
  {
    switch(item)
    {
	    case "front door key":
		  if(mapLocation === 7){
	      gameMessage = "DD finally unlocked the front door! Hurry, let's get out of here!<br >";
		  frontDoorLocked -= 1;
			  
		  //Remove the item from the player's backpack 
          backpack.splice(backpackIndexNumber, 1);
		  }
		  break;
			
	    case "office key":
	      if(mapLocation === 4 && doorLocked === 1)
	      {
	          gameMessage = "DD has unlocked the office door from the westside of the hallway.<br >";
			  doorLocked -= 1;
			  
		  //Remove the item from the player's backpack 
          backpack.splice(backpackIndexNumber, 1);
	      }	     
		  break;
			
	    case "lantern":
	      if(mapLocation === 4 && darkNess === 1)
	      {
	        gameMessage = "DD has used the lantern to brighten the gallery from the eastside of the hallway.<br >";
	        darkNess -= 1;
			  
	        //Remove the item from the player's backpack 
          backpack.splice(backpackIndexNumber, 1);
	      }		     
		  break;
			
		 case "trap":
			if(mapLocation === 3 && traps === 1){
				gameMessage = "DD has successfully trapped the monster!<br >";
	        	traps -= 1;
				//Remove the item from the player's backpack 
				backpack.splice(backpackIndexNumber, 1);
			}
	   }
   }
}

//*****************************************************
//*****************************************************
	

function render()
{
  //Render the location
  output.innerHTML = map[mapLocation];
  image.src = "images/" + images[mapLocation];
  
  //Display an item if there's one in this location
  //1. Loop through all the game items
  for(var i = 0; i < items.length; i++)
  {
   //Find out if there's an item at this location

   if(mapLocation === itemLocations[i])
   {
     //Display it
     output.innerHTML += "<br>DD sees a <strong>" + items[i] + "</strong> here. Want her to take it?<br >";
   }
   
  }
	

  //Display the game message
  output.innerHTML += "<br><em>" + gameMessage + "</em>";
	
  //Display the player's backpack contents
  if(backpack.length !== 0)
  {
    output.innerHTML += "<br>DD is carrying: " + backpack.join(", ");  
  }
}

//*****************************************************
//*****************************************************
	
//The input and output fields
var output = document.querySelector("#output");
var input = document.querySelector("#input");
	
//*****************************************************
//*****************************************************
	
//The button
var button = document.querySelector("button");
button.style.cursor = "pointer";
button.addEventListener("click", clickHandler, false);

//Dispay the player's location
render();

function clickHandler()
{
  playGame();
  input.value = "";
}

	saveButton.onclick = saveInfo;
	loadButton.onclick = loadInfo;

		function saveInfo(){
			"use strict";
			localStorage.setItem("currentLocation",mapLocation);
			localStorage.setItem("inventory",JSON.stringify(backpack));
			localStorage.setItem("itemLantern",lanterns);
			localStorage.setItem("itemTrap",traps);
			
			console.log("Game saved.");
		}
		function loadInfo(){
            if(localStorage.getItem("currentLocation") !== null)
            {
            mapLocation = parseInt(localStorage.getItem("currentLocation"));
			backpack = JSON.parse(localStorage.getItem("inventory"));
			lanterns = parseInt(localStorage.getItem("itemLantern"));
			traps = parseInt(localStorage.getItem("itemTrap"));
			output.innerHTML = map[mapLocation];
  			image.src = "images/" + images[mapLocation];
			console.log("Save loaded.");
            }
			else{
				console.log("No save data found.");
			}
		}	

//*****************************************************
//*****************************************************